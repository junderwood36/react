import { combineReducers } from "redux";
import journey from "./journey";
import suggestion from "./suggestion";

export default combineReducers({ journey, suggestion });
