export default value => (value < 10 ? `0${value}` : value);
